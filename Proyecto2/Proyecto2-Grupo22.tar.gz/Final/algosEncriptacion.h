#include "extras.h"

char EncrptCesar( char nuevo );

char DesEnCesar( char nuevo ); 

char EncrptMurcielago( char nuevo );

char DesEnMurcielago( char nuevo ); 



