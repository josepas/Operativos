#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <stdlib.h>
#include <pthread.h>

long* Rangos(long tamano, long nHijos);

int TomarTiempo();